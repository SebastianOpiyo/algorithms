#include <stdio.h>
#include <stdlib.h>

/*
*Use logical steps and the FlowChart to write a Program
*/

// We define a node of "int" data type and "next" node address
struct Node {
	int data;
	struct Node * next;
};

struct Node* head;   // This a global pointer variable, that can be accessed anywhere.

// Node functions
void InsertToList();
void PrintList();

int main() {
    head = NULL; //we initiate an empty list.
    printf("Enter number of nodes you want to create: ");
    int num_of_nodes, num_entered, i;  // declare variables for nodes, user input & iterator
    scanf("%d", &num_of_nodes); 
    // We can use a while loop instead.
    i = 1; // Because counting begins from zero.
    while (i <= num_of_nodes)
    {
        printf("Enter value for new node: ");
        scanf("%d", &num_entered);
        i ++;
    }
    
}

void InsertToList(){
    // Implement node insertion to a list
};

void PrintList(){
    //Implement code that prints the whole list.

};

